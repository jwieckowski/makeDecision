describe('@dnd-kit/accessibility', () => {
  it('works', () => {
    expect(true).toBe(true);
  });
});

export {};
