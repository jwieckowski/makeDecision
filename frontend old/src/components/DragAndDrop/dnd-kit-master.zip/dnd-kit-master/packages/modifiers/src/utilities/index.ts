export {restrictToBoundingRect} from './restrictToBoundingRect';
