export {isDocument} from './isDocument';
export {isHTMLElement} from './isHTMLElement';
export {isNode} from './isNode';
export {isSVGElement} from './isSVGElement';
export {isWindow} from './isWindow';
