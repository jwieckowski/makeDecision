export type Coordinates = {
  x: number;
  y: number;
};
