export enum Direction {
  Forward = 1,
  Backward = -1,
}
