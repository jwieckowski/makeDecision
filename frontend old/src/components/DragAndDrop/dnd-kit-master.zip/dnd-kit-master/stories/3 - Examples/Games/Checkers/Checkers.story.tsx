export default {
  title: 'Examples/2D Games/Checkers',
};

export {Checkers} from './Checkers';
