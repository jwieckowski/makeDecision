export enum Region {
  Collapse = 'collapse',
  Expand = 'expand',
}

export const MAX_DRAWER_HEIGHT_PERCENT = 0.75;
