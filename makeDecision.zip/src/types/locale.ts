export type HeadersType = {
  locale: string;
};
