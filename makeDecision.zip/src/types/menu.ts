export type MenuSliceState = {
  menuItemIndex: number;
};
