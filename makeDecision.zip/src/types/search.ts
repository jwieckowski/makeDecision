export type SearchSliceState = {
  query: string;
};
