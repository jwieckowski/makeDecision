import CollapseItem from './CollapseItem';

export default CollapseItem;
