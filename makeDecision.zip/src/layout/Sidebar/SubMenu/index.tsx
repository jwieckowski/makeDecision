import AboutMenu from './AboutMenu';
import CalculationsMenu from './CalculationsMenu';

export { AboutMenu, CalculationsMenu };
