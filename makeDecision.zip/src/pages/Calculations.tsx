import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Container, Stack, Typography } from '@mui/material';

// ICONS
import AspectRatioIcon from '@mui/icons-material/AspectRatio';

// REDUX
import { useAppSelector } from '@/state';

// COMPONENTS
import SettingsBar from './CalculationContent/SettingsBar';
import DragStory from './CalculationContent/DragStory';
import Results from './CalculationContent/Results';
import DraggableModal from '@/components/Modal/DraggableModal';

// UTILS
import { scrollToElement } from '@/utils/scroll';

export default function Calculations() {
  const { t } = useTranslation();
  const { results, resultsLoading, errorModalOpen } = useAppSelector((state) => state.calculation);

  console.log(results);

  useEffect(() => {
    if (resultsLoading == false) return;

    scrollToElement('resultsContainer');
  }, [resultsLoading]);

  return (
    <Container maxWidth={false} sx={{ mb: '50px' }} disableGutters>
      <Container maxWidth={false} sx={{ display: { xs: 'none', md: 'block' } }} disableGutters>
        <Container maxWidth={false} disableGutters sx={{ minHeight: '60px', backgroundColor: 'white' }}>
          <SettingsBar />
        </Container>
        <Container maxWidth={false} disableGutters sx={{ minHeight: '70vh' }}>
          <DragStory />
        </Container>
        {results !== null ? (
          <Container maxWidth={false} disableGutters sx={{ marginTop: 2 }}>
            <Results />
          </Container>
        ) : null}
        {errorModalOpen && <DraggableModal />}
      </Container>
      {/* SMALL SCREEN INFO */}
      <Container
        sx={{
          display: { xs: 'flex', md: 'none' },
        }}
      >
        <Stack gap={3} sx={{ marginTop: '100px', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
          <Typography align="center" variant="h4">
            {t('results:work-area')}
          </Typography>
          <AspectRatioIcon sx={{ fontSize: 60 }} />
          <Typography align="center" variant="h6">
            {t('results:work-area-size')}
          </Typography>
          <Typography align="center" variant="h6">
            {t('results:bigger-screen')}
          </Typography>
        </Stack>
      </Container>
    </Container>
  );
}
