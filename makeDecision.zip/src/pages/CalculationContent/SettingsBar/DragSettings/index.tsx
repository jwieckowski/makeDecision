import DragSettings from "./DragSettings";

export default DragSettings;
