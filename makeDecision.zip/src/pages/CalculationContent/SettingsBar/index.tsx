import SettingsBar from './SettingsBar';

export default SettingsBar;
