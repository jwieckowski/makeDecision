import MarkdownText from "./MarkdownText";

export default MarkdownText;
