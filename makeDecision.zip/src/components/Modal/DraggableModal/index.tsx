import DraggableModal from './DraggableModal';

export default DraggableModal;
