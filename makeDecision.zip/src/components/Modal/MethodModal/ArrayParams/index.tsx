import ArrayParams from './ArrayParams';

export default ArrayParams;
