import MethodModal from './MethodModal';

export default MethodModal;
