import MatrixModal from './MatrixModal';

export default MatrixModal;
