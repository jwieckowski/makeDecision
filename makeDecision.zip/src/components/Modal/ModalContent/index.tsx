import ModalContent from "./ModalContent";

export default ModalContent;
