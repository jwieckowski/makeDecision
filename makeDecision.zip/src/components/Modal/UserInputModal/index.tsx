import UserInputModal from './UserInputModal';

export default UserInputModal;
