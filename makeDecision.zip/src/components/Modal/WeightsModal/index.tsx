import WeightsModal from './WeightsModal';

export default WeightsModal;
