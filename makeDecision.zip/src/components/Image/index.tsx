import Image from "./Image";

export default Image;
