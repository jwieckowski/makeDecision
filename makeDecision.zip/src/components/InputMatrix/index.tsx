import InputMatrix from './InputMatrix';

export default InputMatrix;
