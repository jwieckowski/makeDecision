import AccordionResults from './AccordionResults';

export default AccordionResults;
