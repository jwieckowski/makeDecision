import Codes from "./Codes";

export default Codes;
