import Array from './Array';

export default Array;
