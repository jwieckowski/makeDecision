import Language from "./Language";

export default Language;
