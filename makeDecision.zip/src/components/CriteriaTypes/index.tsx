import CriteriaTypes from './CriteriaTypes';

export default CriteriaTypes;
