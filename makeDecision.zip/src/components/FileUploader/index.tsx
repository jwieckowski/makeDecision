import FileUploader from './FileUploader';

export default FileUploader;
