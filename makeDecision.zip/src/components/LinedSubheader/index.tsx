import LinedSubheader from './LinedSubheader';

export default LinedSubheader;
