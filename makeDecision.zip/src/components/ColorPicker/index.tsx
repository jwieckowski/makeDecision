import ColorPicker from './ColorPicker';

export default ColorPicker;
