// CONTACT AND SOCIALS
export const GITHUB_PROFILE_LABEL = 'jwieckowski';
export const GITHUB_PROFILE_LINK = 'https://github.com/jwieckowski';
export const GITHUB_ISSUES_LINK = 'https://github.com/jwieckowski/makeDecision/issues';
export const EMAIL_LABEL = 'j.wieckowski@il-pib.pl';
export const EMAIL_LINK = 'mailto: j.wieckowski@il-pib.pl?subject=GUI MCDA app';
export const COMET_LABEL = 'comet.edu.pl';
export const COMET_LINK = 'http://comet.edu.pl';
export const MCDA_IT_LABEL = 'MCDA Method Selection Tool';
export const MCDA_IT_LINK = 'https://mcda.it/';
