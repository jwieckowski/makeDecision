export const MENU_ITEMS = [
  {
    id: 0,
    href: '/',
  },
  {
    id: 1,
    href: '/calculations',
  },
  {
    id: 2,
    href: '/methods',
  },
  {
    id: 3,
    href: '/about',
  },
  {
    id: 4,
    href: '/contact',
  },
];
