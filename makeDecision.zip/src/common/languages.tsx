export const LANGUAGES = [
  {
    label: 'EN',
    value: 'en',
  },
  {
    label: 'PL',
    value: 'pl',
  },
];
