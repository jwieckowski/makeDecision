# VERSION 1.1 (jwieckowski)

- General app redesign
- Move menu to sidebar
- Move calculation menu to sidebar
- Change calculation logic
- Change calculation data autosave to confirmed save
- Move requests to `api` folder
- Add MCDA methods parameters aligning with pymcdm 1.1 updates
